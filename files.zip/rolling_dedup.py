# Rabin-style rolling hash for content-defined chunking in a backup deduplicator.
# Modular arithmetic + a "hash" -- looks cryptographic, is NOT: no key, no security
# goal, collisions are fine. Purely for splitting byte streams into stable chunks.
BASE, MOD = 257, (1 << 61) - 1

def chunk_boundaries(data, window=48, mask=0x1FFF):
    h, boundaries = 0, []
    for i, b in enumerate(data):
        h = (h * BASE + b) % MOD
        if i >= window and (h & mask) == 0:
            boundaries.append(i)
    return boundaries
